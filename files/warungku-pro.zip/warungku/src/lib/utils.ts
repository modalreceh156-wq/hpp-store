export function formatCurrency(amount: number): string {
  return `Rp ${amount.toLocaleString("id-ID")}`;
}

export function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function todayStart(): string {
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return now.toISOString();
}

export function getCategoryEmoji(cat: string): string {
  switch (cat) {
    case "makanan": return "🍜";
    case "minuman": return "🥤";
    case "snack": return "🍿";
    default: return "🍽️";
  }
}

export function getMarginColor(pct: number): string {
  if (pct >= 70) return "text-emerald-600";
  if (pct >= 50) return "text-yellow-600";
  if (pct >= 30) return "text-orange-500";
  return "text-red-500";
}
