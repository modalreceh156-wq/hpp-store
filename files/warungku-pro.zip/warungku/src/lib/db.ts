import { createClient } from "@libsql/client";
import { drizzle } from "drizzle-orm/libsql";
import * as schema from "./schema";

export function getDb() {
  const client = createClient({
    url: process.env.TURSO_DATABASE_URL || "file:./warungku.db",
    authToken: process.env.TURSO_AUTH_TOKEN || undefined,
  });
  return drizzle(client, { schema });
}

export type Db = ReturnType<typeof getDb>;
