import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";

export const users = sqliteTable("users", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull().default("owner"),
  createdAt: text("created_at").notNull(),
});

export const outlets = sqliteTable("outlets", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  address: text("address"),
  createdAt: text("created_at").notNull(),
});

export const ingredients = sqliteTable("ingredients", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  outletId: text("outlet_id").notNull().references(() => outlets.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  buyPrice: real("buy_price").notNull().default(0),
  buyQty: real("buy_qty").notNull().default(0),
  buyUnit: text("buy_unit").notNull().default("ml"),
  usePerServing: real("use_per_serving").notNull().default(0),
  stock: real("stock").notNull().default(0),
  minStock: real("min_stock").notNull().default(0),
  createdAt: text("created_at").notNull(),
});

export const stockLogs = sqliteTable("stock_logs", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  outletId: text("outlet_id").notNull().references(() => outlets.id, { onDelete: "cascade" }),
  ingredientId: text("ingredient_id").notNull().references(() => ingredients.id, { onDelete: "cascade" }),
  ingredientName: text("ingredient_name").notNull(),
  type: text("type").notNull(),
  qtyChange: real("qty_change").notNull(),
  stockBefore: real("stock_before").notNull(),
  stockAfter: real("stock_after").notNull(),
  note: text("note"),
  createdAt: text("created_at").notNull(),
});

export const recipes = sqliteTable("recipes", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  outletId: text("outlet_id").notNull().references(() => outlets.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  sellPrice: real("sell_price").notNull().default(0),
  category: text("category").notNull().default("makanan"),
  imageUrl: text("image_url"),
  createdAt: text("created_at").notNull(),
});

export const recipeItems = sqliteTable("recipe_items", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  recipeId: text("recipe_id").notNull().references(() => recipes.id, { onDelete: "cascade" }),
  ingredientId: text("ingredient_id").notNull().references(() => ingredients.id, { onDelete: "cascade" }),
  qtyUsed: real("qty_used").notNull().default(0),
  unit: text("unit").notNull().default("pcs"),
});

export const transactions = sqliteTable("transactions", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  outletId: text("outlet_id").notNull().references(() => outlets.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => users.id),
  userName: text("user_name"),
  totalAmount: real("total_amount").notNull().default(0),
  totalHpp: real("total_hpp").notNull().default(0),
  paymentMethod: text("payment_method").notNull().default("tunai"),
  createdAt: text("created_at").notNull(),
});

export const transactionItems = sqliteTable("transaction_items", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  transactionId: text("transaction_id").notNull().references(() => transactions.id, { onDelete: "cascade" }),
  recipeId: text("recipe_id").notNull().references(() => recipes.id),
  qty: integer("qty").notNull().default(1),
  price: real("price").notNull().default(0),
  hpp: real("hpp").notNull().default(0),
});
