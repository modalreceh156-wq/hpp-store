"use client";

import { Settings, LogOut } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function Header({ userName }: { userName?: string }) {
  const router = useRouter();

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
  }

  return (
    <header className="bg-emerald-600 text-white px-4 py-3 flex items-center justify-between sticky top-0 z-40">
      <div>
        <h1 className="text-lg font-bold">🏪 WarungKu</h1>
        {userName && <p className="text-xs text-emerald-100">Halo, {userName}</p>}
      </div>
      <div className="flex items-center gap-3">
        <Link href="/settings" className="p-2 hover:bg-emerald-500 rounded-full">
          <Settings size={20} />
        </Link>
        <button onClick={handleLogout} className="p-2 hover:bg-emerald-500 rounded-full">
          <LogOut size={20} />
        </button>
      </div>
    </header>
  );
}
