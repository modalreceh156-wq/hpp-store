"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Package, UtensilsCrossed, ShoppingCart, BarChart3 } from "lucide-react";

const navItems = [
  { href: "/", label: "Home", icon: Home },
  { href: "/bahan", label: "Bahan", icon: Package },
  { href: "/produk", label: "Produk", icon: UtensilsCrossed },
  { href: "/kasir", label: "Kasir", icon: ShoppingCart },
  { href: "/laporan", label: "Laporan", icon: BarChart3 },
];

export default function BottomNav() {
  const pathname = usePathname();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50 safe-area-bottom">
      <div className="flex justify-around items-center h-16 max-w-lg mx-auto">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center justify-center flex-1 h-full gap-0.5 ${
                isActive ? "text-emerald-600" : "text-gray-400"
              }`}
            >
              <Icon size={22} strokeWidth={isActive ? 2.5 : 2} />
              <span className={`text-[10px] ${isActive ? "font-semibold" : ""}`}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
