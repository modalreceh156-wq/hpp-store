"use client";

import { useEffect, useState } from "react";
import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import { formatCurrency, getCategoryEmoji, getMarginColor } from "@/lib/utils";
import { Plus, Edit2, Trash2, Search, X, ChefHat } from "lucide-react";

interface Ingredient { id: string; name: string; buyPrice: number; buyQty: number; buyUnit: string; usePerServing: number; stock: number; }
interface RecipeItem { ingredientId: string; qtyUsed: number; }
interface Recipe { id: string; name: string; sellPrice: number; category: string; items: RecipeItem[]; }

export default function ProdukPage() {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [sellPrice, setSellPrice] = useState(0);
  const [category, setCategory] = useState("makanan");
  const [items, setItems] = useState<RecipeItem[]>([]);
  const [search, setSearch] = useState("");
  const [filterCat, setFilterCat] = useState("semua");

  async function loadData() {
    const [rRes, iRes] = await Promise.all([fetch("/api/recipes"), fetch("/api/ingredients")]);
    if (rRes.ok) setRecipes(await rRes.json());
    if (iRes.ok) setIngredients(await iRes.json());
    setLoading(false);
  }

  useEffect(() => { loadData(); }, []);

  // HPP = sum of (usePerServing * buyPrice / buyQty) * qtyUsed for each ingredient
  function calcHpp(rItems: RecipeItem[]) {
    return rItems.reduce((sum, ri) => {
      const ing = ingredients.find(i => i.id === ri.ingredientId);
      if (!ing) return sum;
      // HPP per porsi of this ingredient
      const hppPerPorsi = (ing.buyQty > 0 && ing.usePerServing > 0) 
        ? (ing.buyPrice / ing.buyQty) * ing.usePerServing 
        : 0;
      return sum + hppPerPorsi * ri.qtyUsed;
    }, 0);
  }

  function handleAddItem() {
    setItems([...items, { ingredientId: ingredients[0]?.id || "", qtyUsed: 1 }]);
  }

  function handleRemoveItem(idx: number) {
    setItems(items.filter((_, i) => i !== idx));
  }

  function handleItemChange(idx: number, field: string, value: string | number) {
    const updated = [...items];
    (updated[idx] as unknown as Record<string, unknown>)[field] = value;
    setItems(updated);
  }

  async function handleSave() {
    if (!name) return;
    const body = { name, sellPrice, category, items };
    
    if (editId) {
      await fetch(`/api/recipes/${editId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
    } else {
      await fetch("/api/recipes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
    }
    closeForm();
    loadData();
  }

  function openEdit(recipe: Recipe) {
    setEditId(recipe.id);
    setName(recipe.name);
    setSellPrice(recipe.sellPrice);
    setCategory(recipe.category);
    setItems(recipe.items.map(i => ({ ingredientId: i.ingredientId, qtyUsed: i.qtyUsed })));
    setShowForm(true);
  }

  function closeForm() {
    setShowForm(false);
    setEditId(null);
    setName("");
    setSellPrice(0);
    setCategory("makanan");
    setItems([]);
  }

  async function handleDelete(id: string) {
    if (!confirm("Hapus produk ini?")) return;
    await fetch(`/api/recipes/${id}`, { method: "DELETE" });
    loadData();
  }

  const filtered = recipes
    .filter(r => r.name.toLowerCase().includes(search.toLowerCase()))
    .filter(r => filterCat === "semua" || r.category === filterCat);

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <Header />
      
      <div className="p-4 space-y-4">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input type="text" placeholder="Cari produk..." value={search} onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl text-sm" />
          </div>
          <button onClick={() => { closeForm(); setShowForm(true); }}
            className="bg-emerald-600 text-white px-4 py-3 rounded-xl flex items-center gap-1 font-semibold text-sm">
            <Plus size={18} /> Tambah
          </button>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1">
          {["semua", "makanan", "minuman", "snack"].map((cat) => (
            <button key={cat} onClick={() => setFilterCat(cat)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap ${
                filterCat === cat ? "bg-emerald-600 text-white" : "bg-white text-gray-600 border border-gray-200"
              }`}>
              {cat === "semua" ? "Semua" : getCategoryEmoji(cat) + " " + cat.charAt(0).toUpperCase() + cat.slice(1)}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="text-center py-12"><div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full mx-auto" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-gray-400"><ChefHat size={32} className="mx-auto mb-2 opacity-50" /><p>Belum ada produk</p></div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {filtered.map((recipe) => {
              const hpp = calcHpp(recipe.items);
              const margin = recipe.sellPrice > 0 ? ((recipe.sellPrice - hpp) / recipe.sellPrice) * 100 : 0;
              return (
                <div key={recipe.id} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
                  <div className="text-3xl mb-2">{getCategoryEmoji(recipe.category)}</div>
                  <h3 className="font-semibold text-gray-900 text-sm">{recipe.name}</h3>
                  <p className="text-emerald-600 font-bold text-sm mt-1">{formatCurrency(recipe.sellPrice)}</p>
                  <p className="text-xs text-gray-400">HPP: {formatCurrency(Math.round(hpp))}</p>
                  <p className={`text-xs font-medium ${getMarginColor(margin)}`}>Margin: {margin.toFixed(0)}%</p>
                  <div className="flex gap-1 mt-3 pt-2 border-t border-gray-50">
                    <button onClick={() => openEdit(recipe)} className="flex-1 text-xs text-blue-600 flex items-center justify-center gap-1 py-1">
                      <Edit2 size={12} /> Edit
                    </button>
                    <button onClick={() => handleDelete(recipe.id)} className="flex-1 text-xs text-red-500 flex items-center justify-center gap-1 py-1">
                      <Trash2 size={12} /> Hapus
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal Form */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-end sm:items-center justify-center">
          <div className="bg-white rounded-t-2xl sm:rounded-2xl w-full max-w-md p-6 space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">{editId ? "Edit Produk" : "Tambah Produk"}</h2>
              <button onClick={closeForm} className="p-1"><X size={20} /></button>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nama Produk</label>
              <input type="text" value={name} onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm" placeholder="Es Kopi Susu" />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Harga Jual (Rp)</label>
                <input type="number" value={sellPrice || ""} onChange={(e) => setSellPrice(Number(e.target.value))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm" placeholder="15000" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Kategori</label>
                <select value={category} onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm bg-white">
                  <option value="makanan">🍜 Makanan</option>
                  <option value="minuman">🥤 Minuman</option>
                  <option value="snack">🍿 Snack</option>
                </select>
              </div>
            </div>

            {/* Recipe items */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-medium text-gray-700">Bahan (per 1 porsi menu)</label>
                <button onClick={handleAddItem} className="text-xs text-emerald-600 font-medium">+ Tambah Bahan</button>
              </div>
              {ingredients.length === 0 && (
                <p className="text-xs text-orange-500 mb-2">⚠️ Tambah bahan baku dulu di menu Bahan</p>
              )}
              {items.map((item, idx) => {
                const ing = ingredients.find(i => i.id === item.ingredientId);
                const hppPerPorsi = ing ? ((ing.buyQty > 0 && ing.usePerServing > 0) ? (ing.buyPrice / ing.buyQty) * ing.usePerServing : 0) : 0;
                return (
                  <div key={idx} className="bg-gray-50 rounded-xl p-3 mb-2">
                    <div className="flex gap-2">
                      <select value={item.ingredientId} onChange={(e) => handleItemChange(idx, "ingredientId", e.target.value)}
                        className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm bg-white">
                        <option value="">Pilih bahan...</option>
                        {ingredients.map((ing) => (
                          <option key={ing.id} value={ing.id}>{ing.name} ({ing.stock} porsi tersisa)</option>
                        ))}
                      </select>
                      <button onClick={() => handleRemoveItem(idx)} className="text-red-400 px-2">✕</button>
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs text-gray-500">Pakai:</span>
                      <input type="number" value={item.qtyUsed || ""} onChange={(e) => handleItemChange(idx, "qtyUsed", Number(e.target.value))}
                        className="w-16 px-2 py-1 border border-gray-200 rounded-lg text-sm text-center" placeholder="1" />
                      <span className="text-xs text-gray-500">porsi</span>
                      {ing && (
                        <span className="text-xs text-emerald-600 ml-auto">
                          HPP: {formatCurrency(Math.round(hppPerPorsi * item.qtyUsed))}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
              {items.length > 0 && (
                <div className="bg-emerald-50 rounded-xl p-3 mt-2">
                  <div className="flex justify-between">
                    <span className="text-sm font-medium text-gray-700">Total HPP per porsi menu</span>
                    <span className="text-sm font-bold text-emerald-600">{formatCurrency(Math.round(calcHpp(items)))}</span>
                  </div>
                  {sellPrice > 0 && (
                    <div className="flex justify-between mt-1">
                      <span className="text-sm text-gray-500">Profit per porsi</span>
                      <span className="text-sm font-bold text-emerald-600">{formatCurrency(Math.round(sellPrice - calcHpp(items)))}</span>
                    </div>
                  )}
                </div>
              )}
            </div>

            <button onClick={handleSave}
              className="w-full bg-emerald-600 text-white py-3 rounded-xl font-semibold hover:bg-emerald-700">
              {editId ? "Simpan Perubahan" : "Tambah Produk"}
            </button>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
