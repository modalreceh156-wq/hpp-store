"use client";

import { useEffect, useState } from "react";
import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import { formatCurrency, formatDate } from "@/lib/utils";
import { BarChart3, Download, TrendingUp, TrendingDown, DollarSign, Users, Calendar } from "lucide-react";

interface Transaction {
  id: string; totalAmount: number; totalHpp: number; paymentMethod: string; createdAt: string; userName: string;
  items: Array<{ recipeId: string; qty: number; price: number; hpp: number }>;
}

export default function LaporanPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState("today");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [showCustom, setShowCustom] = useState(false);

  useEffect(() => {
    async function load() {
      const res = await fetch("/api/transactions");
      if (res.ok) setTransactions(await res.json());
      setLoading(false);
    }
    load();
  }, []);

  function filterByPeriod(txns: Transaction[]) {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    if (showCustom && dateFrom && dateTo) {
      const from = new Date(dateFrom);
      from.setHours(0, 0, 0, 0);
      const to = new Date(dateTo);
      to.setHours(23, 59, 59, 999);
      return txns.filter(t => { const d = new Date(t.createdAt); return d >= from && d <= to; });
    }

    switch (period) {
      case "today": return txns.filter(t => new Date(t.createdAt) >= today);
      case "week": { const d = new Date(today); d.setDate(d.getDate() - 7); return txns.filter(t => new Date(t.createdAt) >= d); }
      case "month": { const d = new Date(today); d.setMonth(d.getMonth() - 1); return txns.filter(t => new Date(t.createdAt) >= d); }
      default: return txns;
    }
  }

  const filtered = filterByPeriod(transactions);
  const totalSales = filtered.reduce((sum, t) => sum + t.totalAmount, 0);
  const totalHpp = filtered.reduce((sum, t) => sum + t.totalHpp, 0);
  const totalProfit = totalSales - totalHpp;
  const avgMargin = totalSales > 0 ? ((totalProfit / totalSales) * 100) : 0;

  // Chart data: group by day
  function getDailyData() {
    const days: Record<string, { sales: number; profit: number; count: number }> = {};
    filtered.forEach(t => {
      const day = new Date(t.createdAt).toLocaleDateString("id-ID", { day: "2-digit", month: "short" });
      if (!days[day]) days[day] = { sales: 0, profit: 0, count: 0 };
      days[day].sales += t.totalAmount;
      days[day].profit += (t.totalAmount - t.totalHpp);
      days[day].count += 1;
    });
    return Object.entries(days).slice(-7);
  }

  const dailyData = getDailyData();
  const maxSales = Math.max(...dailyData.map(([, d]) => d.sales), 1);

  // Top products
  function getTopProducts() {
    const products: Record<string, { name: string; qty: number; revenue: number }> = {};
    // We need recipe names - use transaction items
    filtered.forEach(t => {
      (t.items || []).forEach(item => {
        if (!products[item.recipeId]) products[item.recipeId] = { name: `Produk`, qty: 0, revenue: 0 };
        products[item.recipeId].qty += item.qty;
        products[item.recipeId].revenue += item.price * item.qty;
      });
    });
    return Object.values(products).sort((a, b) => b.revenue - a.revenue).slice(5);
  }

  function exportCSV() {
    const headers = ["Tanggal", "Total", "HPP", "Profit", "Metode", "Kasir"];
    const rows = filtered.map(t => [
      new Date(t.createdAt).toLocaleDateString("id-ID"),
      t.totalAmount, Math.round(t.totalHpp), Math.round(t.totalAmount - t.totalHpp),
      t.paymentMethod, t.userName || "-",
    ]);
    const csv = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `laporan-warungku-${period}.csv`; a.click();
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <Header />
      <div className="p-4 space-y-4">
        {/* Period filter */}
        <div className="flex gap-2">
          {[{ id: "today", label: "Hari Ini" }, { id: "week", label: "7 Hari" }, { id: "month", label: "30 Hari" }, { id: "all", label: "Semua" }].map((p) => (
            <button key={p.id} onClick={() => { setPeriod(p.id); setShowCustom(false); }}
              className={`flex-1 py-2 rounded-lg text-sm font-medium ${period === p.id && !showCustom ? "bg-emerald-600 text-white" : "bg-white text-gray-600 border border-gray-200"}`}>
              {p.label}
            </button>
          ))}
        </div>

        {/* Custom date */}
        <button onClick={() => setShowCustom(!showCustom)} className="text-xs text-emerald-600 font-medium flex items-center gap-1">
          <Calendar size={14} /> {showCustom ? "Sembunyikan" : "Filter Tanggal"}
        </button>
        {showCustom && (
          <div className="flex gap-2">
            <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)}
              className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm" />
            <span className="self-center text-gray-400">-</span>
            <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)}
              className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm" />
          </div>
        )}

        {/* Summary Cards */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-1"><TrendingUp size={14} className="text-emerald-600" /><span className="text-xs text-gray-500">Penjualan</span></div>
            <p className="text-lg font-bold">{formatCurrency(totalSales)}</p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-1"><TrendingDown size={14} className="text-red-500" /><span className="text-xs text-gray-500">HPP</span></div>
            <p className="text-lg font-bold text-red-500">{formatCurrency(Math.round(totalHpp))}</p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-1"><DollarSign size={14} className="text-emerald-600" /><span className="text-xs text-gray-500">Profit</span></div>
            <p className="text-lg font-bold text-emerald-600">{formatCurrency(Math.round(totalProfit))}</p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-1"><BarChart3 size={14} className="text-blue-500" /><span className="text-xs text-gray-500">Margin</span></div>
            <p className="text-lg font-bold text-blue-500">{avgMargin.toFixed(1)}%</p>
          </div>
        </div>

        {/* Chart */}
        {dailyData.length > 0 && (
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <h3 className="font-semibold text-sm mb-3">📊 Penjualan Harian</h3>
            <div className="flex items-end gap-1.5 h-32">
              {dailyData.map(([day, data]) => (
                <div key={day} className="flex-1 flex flex-col items-center gap-1">
                  <span className="text-[9px] text-gray-400">{formatCurrency(data.sales / 1000)}k</span>
                  <div className="w-full flex flex-col gap-0.5">
                    <div className="bg-emerald-200 rounded-t-sm w-full" style={{ height: `${(data.sales / maxSales) * 80}px` }} />
                    <div className="bg-emerald-500 rounded-b-sm w-full" style={{ height: `${(data.profit / maxSales) * 80}px` }} />
                  </div>
                  <span className="text-[9px] text-gray-500 truncate w-full text-center">{day}</span>
                </div>
              ))}
            </div>
            <div className="flex items-center gap-4 mt-2 justify-center">
              <div className="flex items-center gap-1"><div className="w-3 h-3 bg-emerald-200 rounded-sm" /><span className="text-xs text-gray-500">Penjualan</span></div>
              <div className="flex items-center gap-1"><div className="w-3 h-3 bg-emerald-500 rounded-sm" /><span className="text-xs text-gray-500">Profit</span></div>
            </div>
          </div>
        )}

        {/* Export */}
        <button onClick={exportCSV}
          className="w-full bg-white border border-gray-200 text-gray-700 py-3 rounded-xl flex items-center justify-center gap-2 font-medium text-sm hover:bg-gray-50">
          <Download size={16} /> Export CSV
        </button>

        {/* Transaction List */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100">
          <div className="p-4 border-b border-gray-100 flex items-center justify-between">
            <h2 className="font-semibold">Riwayat ({filtered.length})</h2>
          </div>
          <div className="divide-y divide-gray-50">
            {loading ? (
              <div className="p-8 text-center"><div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full mx-auto" /></div>
            ) : filtered.length === 0 ? (
              <div className="p-8 text-center text-gray-400"><p>Belum ada transaksi</p></div>
            ) : filtered.map((tx) => {
              const profit = tx.totalAmount - tx.totalHpp;
              return (
                <div key={tx.id} className="p-4 flex items-center justify-between">
                  <div>
                    <p className="font-medium text-sm">{formatCurrency(tx.totalAmount)}</p>
                    <p className="text-xs text-gray-400">{formatDate(tx.createdAt)}</p>
                    {tx.userName && <p className="text-xs text-gray-400 flex items-center gap-1"><Users size={10} /> {tx.userName}</p>}
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-emerald-600">+{formatCurrency(Math.round(profit))}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      tx.paymentMethod === "tunai" ? "bg-emerald-100 text-emerald-700" :
                      tx.paymentMethod === "qr" ? "bg-blue-100 text-blue-700" : "bg-purple-100 text-purple-700"
                    }`}>{tx.paymentMethod === "tunai" ? "Tunai" : tx.paymentMethod === "qr" ? "QRIS" : "Transfer"}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      <BottomNav />
    </div>
  );
}
