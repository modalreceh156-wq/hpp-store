"use client";

import { useEffect, useState } from "react";
import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import { formatCurrency, getCategoryEmoji } from "@/lib/utils";
import { ShoppingCart, Plus, Minus, Trash2, X, Check, Search, Printer, Wallet, Banknote, QrCode, Clock } from "lucide-react";

interface Recipe { id: string; name: string; sellPrice: number; category: string; items: Array<{ ingredientId: string; qtyUsed: number }>; }
interface CartItem { recipe: Recipe; qty: number; }
interface ReceiptData {
  total: number; profit: number;
  items: Array<{ name: string; qty: number; price: number; subtotal: number }>;
  uangDiterima: number; kembalian: number; paymentMethod: string; time: string;
}

export default function KasirPage() {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [ingredients, setIngredients] = useState<Array<{ id: string; stock: number }>>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCart, setShowCart] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [showStruk, setShowStruk] = useState(false);
  const [showSaldoModal, setShowSaldoModal] = useState(false);
  const [showQrisWaiting, setShowQrisWaiting] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState("tunai");
  const [search, setSearch] = useState("");
  const [filterCat, setFilterCat] = useState("semua");
  const [processing, setProcessing] = useState(false);
  const [uangDiterima, setUangDiterima] = useState(0);
  const [saldoKasir, setSaldoKasir] = useState(0);
  const [inputSaldo, setInputSaldo] = useState(200000);
  const [qrisImage, setQrisImage] = useState("");
  const [lastTx, setLastTx] = useState<ReceiptData | null>(null);

  useEffect(() => {
    async function load() {
      const [rRes, iRes] = await Promise.all([fetch("/api/recipes"), fetch("/api/ingredients")]);
      if (rRes.ok) setRecipes(await rRes.json());
      if (iRes.ok) setIngredients(await iRes.json());
      setLoading(false);
    }
    load();
    const savedSaldo = localStorage.getItem("warungku_saldo_kasir");
    if (savedSaldo) {
      setSaldoKasir(Number(savedSaldo));
    } else {
      setShowSaldoModal(true);
    }
    const savedQris = localStorage.getItem("warungku_qris_image");
    if (savedQris) setQrisImage(savedQris);
  }, []);

  function getMaxPorsi(recipe: Recipe): number {
    if (!recipe.items || recipe.items.length === 0) return 999;
    let min = 999;
    for (const ri of recipe.items) {
      const ing = ingredients.find(i => i.id === ri.ingredientId);
      if (!ing || ri.qtyUsed <= 0) continue;
      const available = Math.floor(ing.stock / ri.qtyUsed);
      if (available < min) min = available;
    }
    return min;
  }

  function addToCart(recipe: Recipe) {
    const maxPorsi = getMaxPorsi(recipe);
    const inCartQty = cart.find(c => c.recipe.id === recipe.id)?.qty || 0;
    if (inCartQty >= maxPorsi) return;
    setCart((prev) => {
      const existing = prev.find(c => c.recipe.id === recipe.id);
      if (existing) return prev.map(c => c.recipe.id === recipe.id ? { ...c, qty: c.qty + 1 } : c);
      return [...prev, { recipe, qty: 1 }];
    });
  }

  function updateQty(recipeId: string, delta: number) {
    setCart((prev) => prev.map(c => {
      if (c.recipe.id !== recipeId) return c;
      const newQty = c.qty + delta;
      if (newQty <= 0) return c;
      const maxPorsi = getMaxPorsi(c.recipe);
      if (newQty > maxPorsi) return c;
      return { ...c, qty: newQty };
    }).filter(c => c.qty > 0));
  }

  function removeFromCart(recipeId: string) {
    setCart(prev => prev.filter(c => c.recipe.id !== recipeId));
  }

  const totalAmount = cart.reduce((sum, c) => sum + c.recipe.sellPrice * c.qty, 0);
  const totalItems = cart.reduce((sum, c) => sum + c.qty, 0);
  const kembalian = uangDiterima - totalAmount;

  function handleSetSaldo() {
    setSaldoKasir(inputSaldo);
    localStorage.setItem("warungku_saldo_kasir", String(inputSaldo));
    setShowSaldoModal(false);
  }

  function openPayment() {
    if (cart.length === 0) return;
    setUangDiterima(0);
    setShowCart(false);
    setShowPayment(true);
  }

  // QRIS: show QR code, wait for cashier to confirm
  function handleQrisPay() {
    if (!qrisImage) {
      alert("Upload QRIS dulu di Settings!");
      return;
    }
    setShowPayment(false);
    setShowQrisWaiting(true);
  }

  // Cashier confirms QRIS payment received
  async function handleQrisConfirm() {
    await processCheckout("qr");
    setShowQrisWaiting(false);
  }

  async function processCheckout(method: string) {
    if (cart.length === 0) return;
    setProcessing(true);
    try {
      const res = await fetch("/api/transactions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: cart.map(c => ({ recipeId: c.recipe.id, qty: c.qty })),
          paymentMethod: method,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const change = method === "tunai" ? Math.max(0, uangDiterima - totalAmount) : 0;

        if (method === "tunai") {
          const newSaldo = saldoKasir + totalAmount;
          setSaldoKasir(newSaldo);
          localStorage.setItem("warungku_saldo_kasir", String(newSaldo));
        }

        setLastTx({
          total: totalAmount,
          profit: data.profit,
          items: cart.map(c => ({
            name: c.recipe.name,
            qty: c.qty,
            price: c.recipe.sellPrice,
            subtotal: c.recipe.sellPrice * c.qty,
          })),
          uangDiterima: method === "tunai" ? uangDiterima : totalAmount,
          kembalian: change,
          paymentMethod: method,
          time: new Date().toLocaleString("id-ID"),
        });

        setCart([]);
        setShowPayment(false);
        setShowStruk(true);

        const iRes = await fetch("/api/ingredients");
        if (iRes.ok) setIngredients(await iRes.json());
      }
    } catch (e) {
      console.error("Checkout error:", e);
    } finally {
      setProcessing(false);
    }
  }

  async function handleTunaiCheckout() {
    if (paymentMethod === "tunai" && uangDiterima < totalAmount) return;
    await processCheckout("tunai");
  }

  async function handleTransferCheckout() {
    await processCheckout("transfer");
  }

  function handlePrint() {
    if (!lastTx) return;
    const itemsHtml = lastTx.items.map(item => `
      <div style="display:flex;justify-content:space-between;margin-bottom:4px;">
        <div>
          <div style="font-weight:600;font-size:13px;">${item.name}</div>
          <div style="font-size:11px;color:#666;">${item.qty}x ${formatCurrency(item.price)}</div>
        </div>
        <div style="font-weight:600;font-size:13px;">${formatCurrency(item.subtotal)}</div>
      </div>
    `).join("");
    const paymentLabel = lastTx.paymentMethod === "tunai" ? "💵 Tunai" : lastTx.paymentMethod === "qr" ? "📱 QRIS" : "🏦 Transfer";
    const cashSection = lastTx.paymentMethod === "tunai" ? `
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-top:6px;">
        <span style="color:#666;">Uang Diterima</span><span>${formatCurrency(lastTx.uangDiterima)}</span>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-top:2px;">
        <span style="color:#666;">Kembalian</span><span style="font-weight:700;">${formatCurrency(lastTx.kembalian)}</span>
      </div>` : "";
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Struk WarungKu</title>
      <style>*{margin:0;padding:0;box-sizing:border-box;}body{font-family:system-ui,sans-serif;padding:16px;max-width:300px;margin:0 auto;color:#111;}
      .header{text-align:center;border-bottom:2px dashed #ccc;padding-bottom:12px;margin-bottom:12px;}
      .header h1{font-size:20px;font-weight:800;}.header p{font-size:11px;color:#888;margin-top:4px;}
      .divider{border-top:2px dashed #ccc;margin:12px 0;}.total-row{display:flex;justify-content:space-between;font-size:15px;font-weight:800;}
      .footer{text-align:center;margin-top:16px;padding-top:12px;border-top:2px dashed #ccc;}.footer p{font-size:12px;color:#888;}
      @media print{body{padding:8px;}@page{margin:0;size:80mm auto;}}</style></head><body>
      <div class="header"><h1>🏪 WarungKu</h1><p>${lastTx.time}</p></div>
      <div>${itemsHtml}</div><div class="divider"></div>
      <div class="total-row"><span>TOTAL</span><span>${formatCurrency(lastTx.total)}</span></div>
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-top:6px;">
        <span style="color:#666;">Metode</span><span>${paymentLabel}</span></div>
      ${cashSection}
      <div class="footer"><p>Terima kasih! 🙏</p><p style="margin-top:4px;font-size:10px;">WarungKu POS</p></div>
      <script>window.onload=function(){window.print();};</script></body></html>`;
    const w = window.open("", "_blank", "width=400,height=600");
    if (w) { w.document.write(html); w.document.close(); }
  }

  function closeStruk() { setShowStruk(false); setLastTx(null); }

  const quickCash = [10000, 20000, 50000, 100000];
  const filtered = recipes.filter(r => r.name.toLowerCase().includes(search.toLowerCase())).filter(r => filterCat === "semua" || r.category === filterCat);

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <Header />
      <div className="p-4 space-y-4">
        {/* Saldo Kasir */}
        <div className="bg-white rounded-xl p-3 flex items-center justify-between border border-gray-100">
          <div className="flex items-center gap-2">
            <Wallet size={18} className="text-emerald-600" />
            <div>
              <p className="text-xs text-gray-500">Saldo Kasir</p>
              <p className="font-bold text-emerald-600">{formatCurrency(saldoKasir)}</p>
            </div>
          </div>
          <button onClick={() => setShowSaldoModal(true)} className="text-xs text-blue-600 px-3 py-1 bg-blue-50 rounded-lg">Atur</button>
        </div>

        <div className="relative">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input type="text" placeholder="Cari menu..." value={search} onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl text-sm" />
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1">
          {["semua", "makanan", "minuman", "snack"].map((cat) => (
            <button key={cat} onClick={() => setFilterCat(cat)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap ${filterCat === cat ? "bg-emerald-600 text-white" : "bg-white text-gray-600 border border-gray-200"}`}>
              {cat === "semua" ? "Semua" : getCategoryEmoji(cat) + " " + cat.charAt(0).toUpperCase() + cat.slice(1)}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="text-center py-12"><div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full mx-auto" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-gray-400"><p>Belum ada menu</p></div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {filtered.map((recipe) => {
              const inCart = cart.find(c => c.recipe.id === recipe.id);
              const maxPorsi = getMaxPorsi(recipe);
              const soldOut = maxPorsi <= 0;
              return (
                <button key={recipe.id} onClick={() => !soldOut && addToCart(recipe)} disabled={soldOut}
                  className={`bg-white rounded-2xl p-4 shadow-sm border-2 text-left transition-all active:scale-95 ${soldOut ? "border-gray-200 opacity-50" : inCart ? "border-emerald-500 bg-emerald-50" : "border-gray-100"}`}>
                  <div className="text-3xl mb-2">{getCategoryEmoji(recipe.category)}</div>
                  <h3 className="font-semibold text-gray-900 text-sm">{recipe.name}</h3>
                  <p className="text-emerald-600 font-bold mt-1">{formatCurrency(recipe.sellPrice)}</p>
                  <p className={`text-xs mt-1 ${soldOut ? 'text-red-500 font-medium' : 'text-gray-400'}`}>{soldOut ? "Habis" : `${maxPorsi} porsi`}</p>
                  {inCart && !soldOut && <div className="mt-2 bg-emerald-600 text-white text-xs rounded-full px-3 py-1 text-center font-medium">{inCart.qty}x</div>}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Floating Cart */}
      {cart.length > 0 && (
        <button onClick={() => setShowCart(true)}
          className="fixed bottom-20 left-4 right-4 bg-emerald-600 text-white py-4 rounded-2xl shadow-lg flex items-center justify-between px-6 z-40 max-w-lg mx-auto">
          <div className="flex items-center gap-2"><ShoppingCart size={20} /><span className="font-semibold">{totalItems} item</span></div>
          <span className="font-bold text-lg">{formatCurrency(totalAmount)}</span>
        </button>
      )}

      {/* Cart Drawer */}
      {showCart && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="bg-white rounded-t-2xl w-full max-w-lg mx-auto max-h-[80vh] flex flex-col">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between">
              <h2 className="text-lg font-semibold">🛒 Keranjang</h2>
              <button onClick={() => setShowCart(false)} className="p-1"><X size={20} /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {cart.map((item) => (
                <div key={item.recipe.id} className="flex items-center gap-3 bg-gray-50 rounded-xl p-3">
                  <div className="flex-1">
                    <p className="font-medium text-sm">{item.recipe.name}</p>
                    <p className="text-xs text-gray-500">{formatCurrency(item.recipe.sellPrice)} x {item.qty}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => updateQty(item.recipe.id, -1)} className="w-8 h-8 bg-white border border-gray-200 rounded-lg flex items-center justify-center"><Minus size={14} /></button>
                    <span className="w-6 text-center font-semibold text-sm">{item.qty}</span>
                    <button onClick={() => updateQty(item.recipe.id, 1)} className="w-8 h-8 bg-white border border-gray-200 rounded-lg flex items-center justify-center"><Plus size={14} /></button>
                    <button onClick={() => removeFromCart(item.recipe.id)} className="w-8 h-8 text-red-400 flex items-center justify-center"><Trash2 size={14} /></button>
                  </div>
                </div>
              ))}
            </div>
            <div className="p-4 border-t border-gray-100">
              <div className="flex items-center justify-between mb-3">
                <span className="font-semibold">Total</span>
                <span className="font-bold text-xl text-emerald-600">{formatCurrency(totalAmount)}</span>
              </div>
              <button onClick={openPayment}
                className="w-full bg-emerald-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-emerald-700 flex items-center justify-center gap-2">
                <Banknote size={20} /> Bayar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Payment Modal */}
      {showPayment && (
        <div className="fixed inset-0 bg-black/50 z-[55] flex items-end sm:items-center justify-center">
          <div className="bg-white rounded-t-2xl sm:rounded-2xl w-full max-w-md p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">💳 Pembayaran</h2>
              <button onClick={() => setShowPayment(false)} className="p-1"><X size={20} /></button>
            </div>

            <div className="flex gap-2">
              {[{ id: "tunai", label: "💵 Tunai" }, { id: "qr", label: "📱 QRIS" }, { id: "transfer", label: "🏦 Transfer" }].map((pm) => (
                <button key={pm.id} onClick={() => setPaymentMethod(pm.id)}
                  className={`flex-1 py-3 rounded-xl text-sm font-medium ${paymentMethod === pm.id ? "bg-emerald-600 text-white" : "bg-gray-100 text-gray-600"}`}>
                  {pm.label}
                </button>
              ))}
            </div>

            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-sm text-gray-500">Total Tagihan</p>
              <p className="text-3xl font-bold text-emerald-600">{formatCurrency(totalAmount)}</p>
            </div>

            {/* TUNAI */}
            {paymentMethod === "tunai" && (
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">💰 Uang Diterima</label>
                  <input type="number" value={uangDiterima || ""} onChange={(e) => setUangDiterima(Number(e.target.value))}
                    className="w-full px-4 py-4 border-2 border-gray-200 rounded-xl text-2xl font-bold text-center focus:border-emerald-500 focus:ring-0 outline-none" placeholder="0" />
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {quickCash.map((amt) => (
                    <button key={amt} onClick={() => setUangDiterima(amt)}
                      className={`py-2 rounded-lg text-xs font-medium ${uangDiterima === amt ? "bg-emerald-600 text-white" : "bg-gray-100 text-gray-600"}`}>{amt/1000}rb</button>
                  ))}
                  <button onClick={() => setUangDiterima(totalAmount)}
                    className={`py-2 rounded-lg text-xs font-medium ${uangDiterima === totalAmount ? "bg-emerald-600 text-white" : "bg-gray-100 text-gray-600"}`}>Pas</button>
                </div>
                {uangDiterima > 0 && (
                  <div className={`rounded-xl p-4 ${kembalian >= 0 ? "bg-emerald-50 border border-emerald-200" : "bg-red-50 border border-red-200"}`}>
                    <div className="flex items-center justify-between">
                      <span className={`text-sm font-medium ${kembalian >= 0 ? "text-emerald-700" : "text-red-700"}`}>{kembalian >= 0 ? "💵 Kembalian" : "⚠️ Kurang"}</span>
                      <span className={`text-2xl font-bold ${kembalian >= 0 ? "text-emerald-600" : "text-red-600"}`}>{formatCurrency(Math.abs(kembalian))}</span>
                    </div>
                  </div>
                )}
                <button onClick={handleTunaiCheckout}
                  disabled={processing || uangDiterima < totalAmount || uangDiterima === 0}
                  className="w-full bg-emerald-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-emerald-700 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2">
                  <Check size={20} /> {processing ? "Memproses..." : "Konfirmasi Bayar"}
                </button>
              </div>
            )}

            {/* QRIS */}
            {paymentMethod === "qr" && (
              <div className="space-y-3">
                {qrisImage ? (
                  <div className="text-center space-y-3">
                    <div className="bg-white border-2 border-gray-200 rounded-xl p-4 inline-block">
                      <img src={qrisImage} alt="QRIS" className="w-48 h-48 object-contain mx-auto" />
                    </div>
                    <p className="text-sm text-gray-500">Customer scan QR ini lalu bayar dari HP-nya</p>
                    <button onClick={handleQrisPay}
                      className="w-full bg-emerald-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-emerald-700 flex items-center justify-center gap-2">
                      <QrCode size={20} /> Tampilkan QRIS
                    </button>
                  </div>
                ) : (
                  <div className="text-center py-6 space-y-3">
                    <QrCode size={40} className="text-gray-300 mx-auto" />
                    <p className="text-gray-500 text-sm">QRIS belum diupload</p>
                    <a href="/settings" className="text-emerald-600 text-sm font-medium">Upload di Settings →</a>
                  </div>
                )}
              </div>
            )}

            {/* TRANSFER */}
            {paymentMethod === "transfer" && (
              <div className="space-y-3">
                <p className="text-sm text-gray-500 text-center">Customer transfer ke rekening warung</p>
                <button onClick={handleTransferCheckout} disabled={processing}
                  className="w-full bg-emerald-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-emerald-700 disabled:opacity-40 flex items-center justify-center gap-2">
                  <Check size={20} /> {processing ? "Memproses..." : "Konfirmasi Sudah Transfer"}
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* QRIS Waiting Modal */}
      {showQrisWaiting && (
        <div className="fixed inset-0 bg-black/60 z-[58] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-sm p-6 space-y-4 text-center">
            <div className="bg-white border-2 border-gray-200 rounded-xl p-4 inline-block">
              <img src={qrisImage} alt="QRIS" className="w-56 h-56 object-contain mx-auto" />
            </div>
            <div>
              <h2 className="text-xl font-bold">Scan untuk Bayar</h2>
              <p className="text-gray-500 text-sm mt-1">Total: <span className="font-bold text-emerald-600">{formatCurrency(totalAmount)}</span></p>
            </div>

            <div className="flex items-center justify-center gap-2 text-gray-400">
              <Clock size={16} className="animate-pulse" />
              <span className="text-sm">Menunggu pembayaran...</span>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-3">
              <p className="text-xs text-blue-700">📱 Cek notifikasi di HP lu — kalau udah terima dari GoPay/OVO/DANA/BCA, tap tombol di bawah</p>
            </div>

            <button onClick={handleQrisConfirm}
              className="w-full bg-emerald-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-emerald-700 flex items-center justify-center gap-2 animate-pulse">
              <Check size={22} /> ✅ Sudah Bayar
            </button>

            <button onClick={() => setShowQrisWaiting(false)}
              className="w-full text-gray-400 py-2 text-sm font-medium">
              Batal
            </button>
          </div>
        </div>
      )}

      {/* Struk Modal */}
      {showStruk && lastTx && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-sm overflow-hidden">
            <div className="p-6 space-y-3">
              <div className="text-center border-b-2 border-dashed border-gray-300 pb-3">
                <h2 className="text-xl font-extrabold">🏪 WarungKu</h2>
                <p className="text-xs text-gray-400 mt-1">{lastTx.time}</p>
              </div>
              <div className="space-y-2">
                {lastTx.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between">
                    <div>
                      <p className="text-sm font-semibold">{item.name}</p>
                      <p className="text-xs text-gray-400">{item.qty}x {formatCurrency(item.price)}</p>
                    </div>
                    <span className="text-sm font-semibold">{formatCurrency(item.subtotal)}</span>
                  </div>
                ))}
              </div>
              <div className="border-t-2 border-dashed border-gray-300 pt-3 space-y-1.5">
                <div className="flex justify-between">
                  <span className="font-bold">TOTAL</span>
                  <span className="font-extrabold text-xl">{formatCurrency(lastTx.total)}</span>
                </div>
                <div className="flex justify-between text-sm text-gray-500">
                  <span>Metode</span>
                  <span>{lastTx.paymentMethod === "tunai" ? "💵 Tunai" : lastTx.paymentMethod === "qr" ? "📱 QRIS" : "🏦 Transfer"}</span>
                </div>
                {lastTx.paymentMethod === "tunai" && (
                  <>
                    <div className="flex justify-between text-sm text-gray-500"><span>Uang Diterima</span><span>{formatCurrency(lastTx.uangDiterima)}</span></div>
                    <div className="flex justify-between text-sm font-bold"><span>Kembalian</span><span>{formatCurrency(lastTx.kembalian)}</span></div>
                  </>
                )}
              </div>
              <div className="text-center pt-3 border-t-2 border-dashed border-gray-300">
                <p className="text-sm text-gray-500">Terima kasih! 🙏</p>
              </div>
            </div>
            <div className="flex gap-2 p-4 bg-gray-50 border-t border-gray-100">
              <button onClick={handlePrint} className="flex-1 bg-white border border-gray-200 text-gray-700 py-3 rounded-xl flex items-center justify-center gap-2 font-semibold text-sm"><Printer size={16} /> Cetak Struk</button>
              <button onClick={closeStruk} className="flex-1 bg-emerald-600 text-white py-3 rounded-xl flex items-center justify-center gap-2 font-semibold text-sm"><Check size={16} /> Selesai</button>
            </div>
          </div>
        </div>
      )}

      {/* Saldo Modal */}
      {showSaldoModal && (
        <div className="fixed inset-0 bg-black/50 z-[65] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm space-y-4">
            <div className="text-center">
              <Wallet size={32} className="text-emerald-600 mx-auto mb-2" />
              <h2 className="text-lg font-bold">Saldo Awal Kasir</h2>
              <p className="text-sm text-gray-500">Masukkan uang yang ada di laci kasir</p>
            </div>
            <input type="number" value={inputSaldo || ""} onChange={(e) => setInputSaldo(Number(e.target.value))}
              className="w-full px-4 py-4 border-2 border-gray-200 rounded-xl text-2xl font-bold text-center focus:border-emerald-500 focus:ring-0 outline-none" />
            <div className="grid grid-cols-3 gap-2">
              {[100000, 200000, 500000].map((amt) => (
                <button key={amt} onClick={() => setInputSaldo(amt)}
                  className={`py-2 rounded-lg text-sm font-medium ${inputSaldo === amt ? "bg-emerald-600 text-white" : "bg-gray-100 text-gray-600"}`}>{amt/1000}rb</button>
              ))}
            </div>
            <button onClick={handleSetSaldo} className="w-full bg-emerald-600 text-white py-3 rounded-xl font-semibold hover:bg-emerald-700">Simpan</button>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
