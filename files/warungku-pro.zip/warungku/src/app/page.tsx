"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import { formatCurrency, formatDate } from "@/lib/utils";
import { TrendingUp, TrendingDown, AlertTriangle, ShoppingCart, Plus, Package, UtensilsCrossed } from "lucide-react";
import Link from "next/link";

interface DashboardData {
  todaySales: number;
  todayProfit: number;
  lowStockCount: number;
  todayTransactions: number;
  recentTransactions: Array<{ id: string; totalAmount: number; totalHpp: number; paymentMethod: string; createdAt: string }>;
}

export default function DashboardPage() {
  const router = useRouter();
  const [data, setData] = useState<DashboardData | null>(null);
  const [userName, setUserName] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [dashRes, meRes] = await Promise.all([
          fetch("/api/dashboard"),
          fetch("/api/auth/me"),
        ]);

        if (meRes.status === 401) {
          router.push("/login");
          return;
        }

        const me = await meRes.json();
        setUserName(me.name);

        if (dashRes.ok) {
          const dash = await dashRes.json();
          setData(dash);
        }
      } catch {
        router.push("/login");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [router]);

  // Initialize DB on first load
  useEffect(() => {
    fetch("/api/init").catch(() => {});
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <Header userName={userName} />
      
      <div className="p-4 space-y-4">
        {/* Summary Cards */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center">
                <TrendingUp size={16} className="text-emerald-600" />
              </div>
              <span className="text-xs text-gray-500">Penjualan Hari Ini</span>
            </div>
            <p className="text-lg font-bold text-gray-900">{formatCurrency(data?.todaySales || 0)}</p>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center">
                <TrendingDown size={16} className="text-emerald-600" />
              </div>
              <span className="text-xs text-gray-500">Profit Hari Ini</span>
            </div>
            <p className="text-lg font-bold text-emerald-600">{formatCurrency(data?.todayProfit || 0)}</p>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                <AlertTriangle size={16} className="text-orange-500" />
              </div>
              <span className="text-xs text-gray-500">Stok Menipis</span>
            </div>
            <p className="text-lg font-bold text-orange-500">{data?.lowStockCount || 0} item</p>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                <ShoppingCart size={16} className="text-blue-500" />
              </div>
              <span className="text-xs text-gray-500">Transaksi Hari Ini</span>
            </div>
            <p className="text-lg font-bold text-gray-900">{data?.todayTransactions || 0}</p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex gap-3">
          <Link href="/produk" className="flex-1 bg-emerald-600 text-white rounded-xl py-3 px-4 flex items-center justify-center gap-2 font-semibold text-sm hover:bg-emerald-700 transition-colors">
            <Plus size={18} /> Produk
          </Link>
          <Link href="/bahan" className="flex-1 bg-white text-emerald-600 border border-emerald-200 rounded-xl py-3 px-4 flex items-center justify-center gap-2 font-semibold text-sm hover:bg-emerald-50 transition-colors">
            <Package size={18} /> Bahan
          </Link>
          <Link href="/kasir" className="flex-1 bg-orange-500 text-white rounded-xl py-3 px-4 flex items-center justify-center gap-2 font-semibold text-sm hover:bg-orange-600 transition-colors">
            <ShoppingCart size={18} /> Kasir
          </Link>
        </div>

        {/* Recent Transactions */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100">
          <div className="p-4 border-b border-gray-100">
            <h2 className="font-semibold text-gray-900">Transaksi Terakhir</h2>
          </div>
          <div className="divide-y divide-gray-50">
            {data?.recentTransactions?.length === 0 && (
              <div className="p-8 text-center text-gray-400">
                <ShoppingCart size={32} className="mx-auto mb-2 opacity-50" />
                <p>Belum ada transaksi</p>
              </div>
            )}
            {data?.recentTransactions?.map((tx) => (
              <div key={tx.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-900">{formatCurrency(tx.totalAmount)}</p>
                  <p className="text-xs text-gray-400">{formatDate(tx.createdAt)}</p>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  tx.paymentMethod === "tunai" ? "bg-emerald-100 text-emerald-700" :
                  tx.paymentMethod === "qr" ? "bg-blue-100 text-blue-700" :
                  "bg-purple-100 text-purple-700"
                }`}>
                  {tx.paymentMethod === "tunai" ? "💵 Tunai" : tx.paymentMethod === "qr" ? "📱 QRIS" : "🏦 Transfer"}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
