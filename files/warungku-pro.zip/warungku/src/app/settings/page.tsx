"use client";

import { useEffect, useState, useRef } from "react";
import { useRouter } from "next/navigation";
import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import { User, LogOut, Info, QrCode, Upload, X, Save, Users, UserPlus, Trash2, Download, RotateCcw, Send } from "lucide-react";

interface Kasir { id: string; name: string; email: string; role: string; }

export default function SettingsPage() {
  const router = useRouter();
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);
  const [qrisImage, setQrisImage] = useState("");
  const [showQrisModal, setShowQrisModal] = useState(false);
  const [qrisInput, setQrisInput] = useState("");
  const [kasirList, setKasirList] = useState<Kasir[]>([]);
  const [showAddKasir, setShowAddKasir] = useState(false);
  const [kasirForm, setKasirForm] = useState({ name: "", email: "", password: "" });
  const [showRestore, setShowRestore] = useState(false);
  const [restoreFile, setRestoreFile] = useState<File | null>(null);
  const [telegramChatId, setTelegramChatId] = useState("");
  const [showTelegram, setShowTelegram] = useState(false);
  const [statusMsg, setStatusMsg] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetch("/api/auth/me").then(r => r.json()).then(setUser).catch(() => router.push("/login"));
    const saved = localStorage.getItem("warungku_qris_image");
    if (saved) setQrisImage(saved);
    const savedTg = localStorage.getItem("warungku_telegram_chat_id");
    if (savedTg) setTelegramChatId(savedTg);
    loadKasir();
  }, [router]);

  async function loadKasir() {
    const res = await fetch("/api/team");
    if (res.ok) setKasirList(await res.json());
  }

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
  }

  function handleSaveQris() {
    if (qrisInput) { setQrisImage(qrisInput); localStorage.setItem("warungku_qris_image", qrisInput); }
    setShowQrisModal(false);
  }

  function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setQrisInput(reader.result as string);
    reader.readAsDataURL(file);
  }

  async function handleAddKasir() {
    if (!kasirForm.name || !kasirForm.email || !kasirForm.password) return;
    const res = await fetch("/api/team", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(kasirForm),
    });
    if (res.ok) {
      setShowAddKasir(false);
      setKasirForm({ name: "", email: "", password: "" });
      loadKasir();
      showStatus("Kasir berhasil ditambahkan!");
    } else {
      const data = await res.json();
      showStatus(data.error || "Gagal menambah kasir");
    }
  }

  async function handleDeleteKasir(id: string) {
    if (!confirm("Hapus kasir ini?")) return;
    await fetch(`/api/team?id=${id}`, { method: "DELETE" });
    loadKasir();
  }

  async function handleBackup() {
    showStatus("Mengunduh backup...");
    const res = await fetch("/api/backup");
    if (res.ok) {
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url;
      a.download = `warungku-backup-${new Date().toISOString().split("T")[0]}.json`;
      a.click();
      showStatus("Backup berhasil diunduh!");
    }
  }

  async function handleRestore() {
    if (!restoreFile) return;
    showStatus("Memulihkan data...");
    const text = await restoreFile.text();
    try {
      const data = JSON.parse(text);
      const res = await fetch("/api/backup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        showStatus("Data berhasil dipulihkan!");
        setShowRestore(false);
      } else {
        showStatus("Gagal memulihkan data");
      }
    } catch {
      showStatus("File tidak valid");
    }
  }

  function handleSaveTelegram() {
    localStorage.setItem("warungku_telegram_chat_id", telegramChatId);
    showStatus("Chat ID Telegram disimpan!");
    setShowTelegram(false);
  }

  function showStatus(msg: string) {
    setStatusMsg(msg);
    setTimeout(() => setStatusMsg(""), 3000);
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <Header />
      <div className="p-4 space-y-4">
        {/* Status message */}
        {statusMsg && (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm p-3 rounded-xl text-center font-medium">{statusMsg}</div>
        )}

        {/* Profile */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center"><User size={24} className="text-emerald-600" /></div>
            <div>
              <h2 className="font-bold text-lg">{user?.name || "..."}</h2>
              <p className="text-sm text-gray-500">{user?.email || "..."}</p>
              <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">Owner</span>
            </div>
          </div>
        </div>

        {/* QRIS */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-4 border-b border-gray-100">
            <div className="flex items-center gap-2"><QrCode size={18} className="text-emerald-600" /><h3 className="font-semibold">QRIS Saya</h3></div>
          </div>
          <div className="p-4">
            {qrisImage ? (
              <div className="space-y-3">
                <div className="bg-gray-50 rounded-xl p-4 flex items-center justify-center">
                  <img src={qrisImage} alt="QRIS" className="max-w-48 max-h-48 object-contain rounded-lg" />
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setShowQrisModal(true)} className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg text-sm font-medium flex items-center justify-center gap-1"><Upload size={14} /> Ganti</button>
                  <button onClick={() => { setQrisImage(""); localStorage.removeItem("warungku_qris_image"); }} className="flex-1 bg-red-50 text-red-600 py-2 rounded-lg text-sm font-medium flex items-center justify-center gap-1"><X size={14} /> Hapus</button>
                </div>
              </div>
            ) : (
              <button onClick={() => setShowQrisModal(true)} className="w-full bg-emerald-50 border-2 border-dashed border-emerald-300 text-emerald-600 py-6 rounded-xl flex flex-col items-center gap-2">
                <Upload size={24} /><span className="font-medium text-sm">Upload QRIS</span>
              </button>
            )}
          </div>
        </div>

        {/* Team / Kasir */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-4 border-b border-gray-100 flex items-center justify-between">
            <div className="flex items-center gap-2"><Users size={18} className="text-emerald-600" /><h3 className="font-semibold">Tim Kasir</h3></div>
            <button onClick={() => setShowAddKasir(true)} className="text-xs text-emerald-600 font-medium flex items-center gap-1"><UserPlus size={14} /> Tambah</button>
          </div>
          <div className="divide-y divide-gray-50">
            {kasirList.length === 0 ? (
              <p className="p-4 text-sm text-gray-400 text-center">Belum ada kasir</p>
            ) : kasirList.map((k) => (
              <div key={k.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-sm">{k.name}</p>
                  <p className="text-xs text-gray-400">{k.email}</p>
                </div>
                <button onClick={() => handleDeleteKasir(k.id)} className="text-red-400 p-2"><Trash2 size={16} /></button>
              </div>
            ))}
          </div>
        </div>

        {/* Telegram Auto-Report */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-4 border-b border-gray-100 flex items-center justify-between">
            <div className="flex items-center gap-2"><Send size={18} className="text-blue-500" /><h3 className="font-semibold">Laporan Otomatis Telegram</h3></div>
            <button onClick={() => setShowTelegram(true)} className="text-xs text-blue-600 font-medium">Atur</button>
          </div>
          <div className="p-4">
            {telegramChatId ? (
              <p className="text-sm text-gray-600">✅ Aktif — Chat ID: <span className="font-mono text-xs">{telegramChatId}</span></p>
            ) : (
              <p className="text-sm text-gray-400">Belum dikonfigurasi</p>
            )}
          </div>
        </div>

        {/* Backup & Restore */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-4 border-b border-gray-100">
            <div className="flex items-center gap-2"><Download size={18} className="text-emerald-600" /><h3 className="font-semibold">Backup & Restore</h3></div>
          </div>
          <div className="p-4 flex gap-2">
            <button onClick={handleBackup} className="flex-1 bg-emerald-600 text-white py-3 rounded-xl font-medium text-sm flex items-center justify-center gap-2 hover:bg-emerald-700">
              <Download size={16} /> Backup
            </button>
            <button onClick={() => setShowRestore(true)} className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium text-sm flex items-center justify-center gap-2 hover:bg-gray-200">
              <RotateCcw size={16} /> Restore
            </button>
          </div>
        </div>

        {/* App Info */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100">
          <div className="p-4 flex items-center gap-3">
            <Info size={18} className="text-gray-400" />
            <div><p className="text-sm font-medium">WarungKu</p><p className="text-xs text-gray-400">POS & HPP Dashboard v1.2</p></div>
          </div>
        </div>

        <button onClick={handleLogout} className="w-full bg-red-50 text-red-600 py-3 rounded-xl flex items-center justify-center gap-2 font-medium hover:bg-red-100">
          <LogOut size={18} /> Keluar
        </button>
      </div>

      {/* QRIS Modal */}
      {showQrisModal && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm space-y-4">
            <div className="flex items-center justify-between"><h2 className="text-lg font-semibold">Upload QRIS</h2><button onClick={() => { setShowQrisModal(false); setQrisInput(""); }} className="p-1"><X size={20} /></button></div>
            {qrisInput && <div className="bg-gray-50 rounded-xl p-4 flex items-center justify-center"><img src={qrisInput} alt="Preview" className="max-w-40 max-h-40 object-contain rounded-lg" /></div>}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Pilih gambar QRIS</label>
              <input type="file" accept="image/*" onChange={handleFileUpload} className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-emerald-50 file:text-emerald-700" />
            </div>
            <button onClick={handleSaveQris} disabled={!qrisInput} className="w-full bg-emerald-600 text-white py-3 rounded-xl font-semibold hover:bg-emerald-700 disabled:opacity-40"><Save size={16} /> Simpan</button>
          </div>
        </div>
      )}

      {/* Add Kasir Modal */}
      {showAddKasir && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm space-y-4">
            <div className="flex items-center justify-between"><h2 className="text-lg font-semibold">Tambah Kasir</h2><button onClick={() => setShowAddKasir(false)} className="p-1"><X size={20} /></button></div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nama</label>
              <input type="text" value={kasirForm.name} onChange={(e) => setKasirForm({...kasirForm, name: e.target.value})} className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm" placeholder="Nama kasir" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input type="email" value={kasirForm.email} onChange={(e) => setKasirForm({...kasirForm, email: e.target.value})} className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm" placeholder="kasir@warung.com" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <input type="password" value={kasirForm.password} onChange={(e) => setKasirForm({...kasirForm, password: e.target.value})} className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm" placeholder="Minimal 6 karakter" />
            </div>
            <button onClick={handleAddKasir} className="w-full bg-emerald-600 text-white py-3 rounded-xl font-semibold hover:bg-emerald-700"><UserPlus size={16} /> Tambah Kasir</button>
          </div>
        </div>
      )}

      {/* Restore Modal */}
      {showRestore && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm space-y-4">
            <div className="flex items-center justify-between"><h2 className="text-lg font-semibold">Restore Data</h2><button onClick={() => setShowRestore(false)} className="p-1"><X size={20} /></button></div>
            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-3">
              <p className="text-xs text-yellow-700">⚠️ Semua data saat ini akan ditimpa dengan data dari file backup!</p>
            </div>
            <input ref={fileRef} type="file" accept=".json" onChange={(e) => setRestoreFile(e.target.files?.[0] || null)}
              className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-emerald-50 file:text-emerald-700" />
            <button onClick={handleRestore} disabled={!restoreFile} className="w-full bg-emerald-600 text-white py-3 rounded-xl font-semibold hover:bg-emerald-700 disabled:opacity-40"><RotateCcw size={16} /> Restore Sekarang</button>
          </div>
        </div>
      )}

      {/* Telegram Modal */}
      {showTelegram && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm space-y-4">
            <div className="flex items-center justify-between"><h2 className="text-lg font-semibold">🤖 Telegram Auto-Report</h2><button onClick={() => setShowTelegram(false)} className="p-1"><X size={20} /></button></div>
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-3">
              <p className="text-xs text-blue-700 mb-2">Cara dapat Chat ID:</p>
              <ol className="text-xs text-blue-700 space-y-1 list-decimal list-inside">
                <li>Buka Telegram, search <span className="font-mono">@userinfobot</span></li>
                <li>Klik Start</li>
                <li>Chat ID ada di balasan pertama</li>
              </ol>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Chat ID Telegram</label>
              <input type="text" value={telegramChatId} onChange={(e) => setTelegramChatId(e.target.value)} className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm font-mono" placeholder="123456789" />
            </div>
            <button onClick={handleSaveTelegram} className="w-full bg-emerald-600 text-white py-3 rounded-xl font-semibold hover:bg-emerald-700"><Save size={16} /> Simpan</button>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
