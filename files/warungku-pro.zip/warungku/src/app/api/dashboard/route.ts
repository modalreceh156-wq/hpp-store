import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { transactions, ingredients, outlets } from "@/lib/schema";
import { getSession } from "@/lib/auth";
import { eq, gte, and, desc, sql } from "drizzle-orm";

export async function GET() {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const db = getDb();
    const userOutlets = await db.select().from(outlets).where(eq(outlets.userId, session.id)).limit(1);
    if (userOutlets.length === 0) {
      return NextResponse.json({ todaySales: 0, todayProfit: 0, lowStockCount: 0, todayTransactions: 0, recentTransactions: [] });
    }

    const outletId = userOutlets[0].id;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStr = today.toISOString();

    const todayTxns = await db.select().from(transactions)
      .where(and(eq(transactions.outletId, outletId), gte(transactions.createdAt, todayStr)));

    const todaySales = todayTxns.reduce((sum, tx) => sum + tx.totalAmount, 0);
    const todayProfit = todayTxns.reduce((sum, tx) => sum + (tx.totalAmount - tx.totalHpp), 0);

    const allIngredients = await db.select().from(ingredients).where(eq(ingredients.outletId, outletId));
    const lowStockCount = allIngredients.filter(i => i.stock <= i.minStock && i.minStock > 0).length;

    const recentTxns = await db.select().from(transactions)
      .where(eq(transactions.outletId, outletId))
      .orderBy(desc(transactions.createdAt))
      .limit(5);

    return NextResponse.json({
      todaySales,
      todayProfit,
      lowStockCount,
      todayTransactions: todayTxns.length,
      recentTransactions: recentTxns,
    });
  } catch (error) {
    console.error("GET dashboard error:", error);
    return NextResponse.json({ error: "Gagal mengambil data" }, { status: 500 });
  }
}
