import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { sql } from "drizzle-orm";

export async function GET() {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    
    const db = getDb();
    // Initialize tables
    await db.run(sql`CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`);
    await db.run(sql`CREATE TABLE IF NOT EXISTS outlets (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      address TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`);
    await db.run(sql`CREATE TABLE IF NOT EXISTS ingredients (
      id TEXT PRIMARY KEY,
      outlet_id TEXT NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      buy_price REAL NOT NULL DEFAULT 0,
      buy_qty REAL NOT NULL DEFAULT 0,
      buy_unit TEXT NOT NULL DEFAULT 'pcs',
      stock REAL NOT NULL DEFAULT 0,
      stock_unit TEXT NOT NULL DEFAULT 'pcs',
      min_stock REAL NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`);
    await db.run(sql`CREATE TABLE IF NOT EXISTS recipes (
      id TEXT PRIMARY KEY,
      outlet_id TEXT NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      sell_price REAL NOT NULL DEFAULT 0,
      category TEXT NOT NULL DEFAULT 'makanan',
      image_url TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`);
    await db.run(sql`CREATE TABLE IF NOT EXISTS recipe_items (
      id TEXT PRIMARY KEY,
      recipe_id TEXT NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
      ingredient_id TEXT NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
      qty_used REAL NOT NULL DEFAULT 0,
      unit TEXT NOT NULL DEFAULT 'pcs'
    )`);
    await db.run(sql`CREATE TABLE IF NOT EXISTS transactions (
      id TEXT PRIMARY KEY,
      outlet_id TEXT NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL REFERENCES users(id),
      total_amount REAL NOT NULL DEFAULT 0,
      total_hpp REAL NOT NULL DEFAULT 0,
      payment_method TEXT NOT NULL DEFAULT 'tunai',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`);
    await db.run(sql`CREATE TABLE IF NOT EXISTS transaction_items (
      id TEXT PRIMARY KEY,
      transaction_id TEXT NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
      recipe_id TEXT NOT NULL REFERENCES recipes(id),
      qty INTEGER NOT NULL DEFAULT 1,
      price REAL NOT NULL DEFAULT 0,
      hpp REAL NOT NULL DEFAULT 0
    )`);
    
    return NextResponse.json({ success: true, message: "Database initialized" });
  } catch (error) {
    console.error("Init DB error:", error);
    return NextResponse.json({ error: "Gagal inisialisasi database" }, { status: 500 });
  }
}
