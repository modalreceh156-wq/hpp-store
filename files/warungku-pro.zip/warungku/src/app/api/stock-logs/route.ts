import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { stockLogs, outlets } from "@/lib/schema";
import { getSession } from "@/lib/auth";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const db = getDb();
    const userOutlets = await db.select().from(outlets).where(eq(outlets.userId, session.id)).limit(1);
    if (userOutlets.length === 0) return NextResponse.json([]);
    const logs = await db.select().from(stockLogs)
      .where(eq(stockLogs.outletId, userOutlets[0].id))
      .orderBy(desc(stockLogs.createdAt))
      .limit(100);
    return NextResponse.json(logs);
  } catch (error) {
    console.error("GET stock-logs error:", error);
    return NextResponse.json({ error: "Gagal mengambil data" }, { status: 500 });
  }
}
