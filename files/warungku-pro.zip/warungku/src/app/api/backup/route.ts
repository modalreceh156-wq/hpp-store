import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { ingredients, recipes, recipeItems, transactions, transactionItems, outlets, stockLogs } from "@/lib/schema";
import { getSession } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const db = getDb();
    const userOutlets = await db.select().from(outlets).where(eq(outlets.userId, session.id)).limit(1);
    if (userOutlets.length === 0) return NextResponse.json({ error: "Outlet tidak ditemukan" }, { status: 400 });
    const outletId = userOutlets[0].id;

    const [ings, recs, recItems, txns, txItems, logs] = await Promise.all([
      db.select().from(ingredients).where(eq(ingredients.outletId, outletId)),
      db.select().from(recipes).where(eq(recipes.outletId, outletId)),
      db.select().from(recipeItems),
      db.select().from(transactions).where(eq(transactions.outletId, outletId)),
      db.select().from(transactionItems),
      db.select().from(stockLogs).where(eq(stockLogs.outletId, outletId)),
    ]);

    const backup = {
      version: "1.0",
      exportedAt: new Date().toISOString(),
      outlet: userOutlets[0],
      ingredients: ings,
      recipes: recs,
      recipeItems: recItems,
      transactions: txns,
      transactionItems: txItems,
      stockLogs: logs,
    };

    return new NextResponse(JSON.stringify(backup, null, 2), {
      headers: {
        "Content-Type": "application/json",
        "Content-Disposition": `attachment; filename="warungku-backup-${new Date().toISOString().split("T")[0]}.json"`,
      },
    });
  } catch (error) {
    console.error("GET backup error:", error);
    return NextResponse.json({ error: "Gagal backup" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const db = getDb();
    const userOutlets = await db.select().from(outlets).where(eq(outlets.userId, session.id)).limit(1);
    if (userOutlets.length === 0) return NextResponse.json({ error: "Outlet tidak ditemukan" }, { status: 400 });
    const outletId = userOutlets[0].id;

    const backup = await request.json();
    if (!backup.version || !backup.ingredients) {
      return NextResponse.json({ error: "File backup tidak valid" }, { status: 400 });
    }

    // Clear existing data
    await db.delete(stockLogs).where(eq(stockLogs.outletId, outletId));
    await db.delete(transactionItems);
    await db.delete(transactions).where(eq(transactions.outletId, outletId));
    await db.delete(recipeItems);
    await db.delete(recipes).where(eq(recipes.outletId, outletId));
    await db.delete(ingredients).where(eq(ingredients.outletId, outletId));

    // Restore ingredients
    if (backup.ingredients?.length) {
      await db.insert(ingredients).values(backup.ingredients.map((i: Record<string, unknown>) => ({ ...i, outletId })));
    }
    // Restore recipes
    if (backup.recipes?.length) {
      await db.insert(recipes).values(backup.recipes.map((r: Record<string, unknown>) => ({ ...r, outletId })));
    }
    // Restore recipe items
    if (backup.recipeItems?.length) {
      await db.insert(recipeItems).values(backup.recipeItems);
    }
    // Restore transactions
    if (backup.transactions?.length) {
      await db.insert(transactions).values(backup.transactions.map((t: Record<string, unknown>) => ({ ...t, outletId })));
    }
    // Restore transaction items
    if (backup.transactionItems?.length) {
      await db.insert(transactionItems).values(backup.transactionItems);
    }
    // Restore stock logs
    if (backup.stockLogs?.length) {
      await db.insert(stockLogs).values(backup.stockLogs.map((l: Record<string, unknown>) => ({ ...l, outletId })));
    }

    return NextResponse.json({ success: true, message: "Data berhasil dipulihkan" });
  } catch (error) {
    console.error("POST restore error:", error);
    return NextResponse.json({ error: "Gagal restore" }, { status: 500 });
  }
}
