import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { transactions, transactionItems, recipes, recipeItems, ingredients, outlets, stockLogs } from "@/lib/schema";
import { getSession } from "@/lib/auth";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const db = getDb();
    const userOutlets = await db.select().from(outlets).where(eq(outlets.userId, session.id)).limit(1);
    if (userOutlets.length === 0) return NextResponse.json([]);
    const txns = await db.select().from(transactions)
      .where(eq(transactions.outletId, userOutlets[0].id))
      .orderBy(desc(transactions.createdAt)).limit(100);
    const result = await Promise.all(txns.map(async (tx) => {
      const items = await db.select().from(transactionItems).where(eq(transactionItems.transactionId, tx.id));
      return { ...tx, items };
    }));
    return NextResponse.json(result);
  } catch (error) {
    console.error("GET transactions error:", error);
    return NextResponse.json({ error: "Gagal mengambil data" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const body = await request.json();
    const db = getDb();
    const userOutlets = await db.select().from(outlets).where(eq(outlets.userId, session.id)).limit(1);
    if (userOutlets.length === 0) return NextResponse.json({ error: "Outlet tidak ditemukan" }, { status: 400 });

    const outletId = userOutlets[0].id;
    let totalAmount = 0;
    let totalHpp = 0;
    const txItems = [];

    for (const item of body.items) {
      const [recipe] = await db.select().from(recipes).where(eq(recipes.id, item.recipeId)).limit(1);
      if (!recipe) continue;
      const rItems = await db.select().from(recipeItems).where(eq(recipeItems.recipeId, recipe.id));
      
      let itemHpp = 0;
      for (const ri of rItems) {
        const [ing] = await db.select().from(ingredients).where(eq(ingredients.id, ri.ingredientId)).limit(1);
        if (ing) {
          const hppPerPorsi = (ing.buyQty > 0 && ing.usePerServing > 0) ? (ing.buyPrice / ing.buyQty) * ing.usePerServing : 0;
          itemHpp += hppPerPorsi * ri.qtyUsed;

          const deduct = ri.qtyUsed * item.qty;
          const stockBefore = ing.stock;
          const newStock = Math.max(0, stockBefore - deduct);
          await db.update(ingredients).set({ stock: newStock }).where(eq(ingredients.id, ri.ingredientId));

          // Log stock change
          await db.insert(stockLogs).values({
            outletId,
            ingredientId: ri.ingredientId,
            ingredientName: ing.name,
            type: "sale",
            qtyChange: -deduct,
            stockBefore,
            stockAfter: newStock,
            note: `Penjualan ${recipe.name} x${item.qty}`,
            createdAt: new Date().toISOString(),
          });
        }
      }

      totalAmount += recipe.sellPrice * item.qty;
      totalHpp += itemHpp * item.qty;
      txItems.push({ recipeId: recipe.id, qty: item.qty, price: recipe.sellPrice, hpp: itemHpp });
    }

    const [tx] = await db.insert(transactions).values({
      outletId,
      userId: session.id,
      userName: session.name,
      totalAmount,
      totalHpp,
      paymentMethod: body.paymentMethod || "tunai",
      createdAt: new Date().toISOString(),
    }).returning();

    await db.insert(transactionItems).values(
      txItems.map((item) => ({ transactionId: tx.id, recipeId: item.recipeId, qty: item.qty, price: item.price, hpp: item.hpp }))
    );

    return NextResponse.json({ ...tx, items: txItems, profit: totalAmount - totalHpp });
  } catch (error) {
    console.error("POST transactions error:", error);
    return NextResponse.json({ error: "Gagal membuat transaksi" }, { status: 500 });
  }
}
