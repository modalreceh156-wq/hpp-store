import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { recipes, recipeItems } from "@/lib/schema";
import { getSession } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const { id } = await params;
    const body = await request.json();
    const db = getDb();

    const [updated] = await db.update(recipes).set({
      name: body.name,
      sellPrice: body.sellPrice,
      category: body.category,
      imageUrl: body.imageUrl,
    }).where(eq(recipes.id, id)).returning();

    // Update recipe items: delete old, insert new
    if (body.items) {
      await db.delete(recipeItems).where(eq(recipeItems.recipeId, id));
      if (body.items.length > 0) {
        await db.insert(recipeItems).values(
          body.items.map((item: { ingredientId: string; qtyUsed: number; unit: string }) => ({
            recipeId: id,
            ingredientId: item.ingredientId,
            qtyUsed: item.qtyUsed,
            unit: item.unit || "pcs",
          }))
        );
      }
    }

    const items = await db.select().from(recipeItems).where(eq(recipeItems.recipeId, id));
    return NextResponse.json({ ...updated, items });
  } catch (error) {
    console.error("PUT recipes error:", error);
    return NextResponse.json({ error: "Gagal update produk" }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const { id } = await params;
    const db = getDb();
    await db.delete(recipeItems).where(eq(recipeItems.recipeId, id));
    await db.delete(recipes).where(eq(recipes.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE recipes error:", error);
    return NextResponse.json({ error: "Gagal hapus produk" }, { status: 500 });
  }
}
