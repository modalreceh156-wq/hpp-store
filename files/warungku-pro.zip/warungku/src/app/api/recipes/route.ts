import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { recipes, recipeItems, outlets } from "@/lib/schema";
import { getSession } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const db = getDb();
    const userOutlets = await db.select().from(outlets).where(eq(outlets.userId, session.id)).limit(1);
    if (userOutlets.length === 0) return NextResponse.json([]);

    const items = await db.select().from(recipes).where(eq(recipes.outletId, userOutlets[0].id));
    
    const result = await Promise.all(items.map(async (recipe) => {
      const ri = await db.select().from(recipeItems).where(eq(recipeItems.recipeId, recipe.id));
      return { ...recipe, items: ri };
    }));

    return NextResponse.json(result);
  } catch (error) {
    console.error("GET recipes error:", error);
    return NextResponse.json({ error: "Gagal mengambil data" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await request.json();
    const db = getDb();
    const userOutlets = await db.select().from(outlets).where(eq(outlets.userId, session.id)).limit(1);
    if (userOutlets.length === 0) return NextResponse.json({ error: "Outlet tidak ditemukan" }, { status: 400 });

    const [recipe] = await db.insert(recipes).values({
      outletId: userOutlets[0].id,
      name: body.name,
      sellPrice: body.sellPrice || 0,
      category: body.category || "makanan",
      imageUrl: body.imageUrl || null,
      createdAt: new Date().toISOString(),
    }).returning();

    if (body.items && body.items.length > 0) {
      await db.insert(recipeItems).values(
        body.items.map((item: { ingredientId: string; qtyUsed: number; unit: string }) => ({
          recipeId: recipe.id,
          ingredientId: item.ingredientId,
          qtyUsed: item.qtyUsed,
          unit: item.unit || "pcs",
        }))
      );
    }

    const ri = await db.select().from(recipeItems).where(eq(recipeItems.recipeId, recipe.id));
    return NextResponse.json({ ...recipe, items: ri });
  } catch (error) {
    console.error("POST recipes error:", error);
    return NextResponse.json({ error: "Gagal menambah produk" }, { status: 500 });
  }
}
