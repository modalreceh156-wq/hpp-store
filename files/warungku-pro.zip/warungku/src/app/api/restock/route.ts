import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { ingredients, stockLogs, outlets } from "@/lib/schema";
import { getSession } from "@/lib/auth";
import { eq, and } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const body = await request.json();
    const db = getDb();
    const userOutlets = await db.select().from(outlets).where(eq(outlets.userId, session.id)).limit(1);
    if (userOutlets.length === 0) return NextResponse.json({ error: "Outlet tidak ditemukan" }, { status: 400 });
    const outletId = userOutlets[0].id;

    const [ing] = await db.select().from(ingredients).where(eq(ingredients.id, body.ingredientId)).limit(1);
    if (!ing) return NextResponse.json({ error: "Bahan tidak ditemukan" }, { status: 404 });

    const stockBefore = ing.stock;
    const addQty = body.qty || 0;
    const newStock = stockBefore + addQty;

    // Update stock
    await db.update(ingredients).set({ stock: newStock }).where(eq(ingredients.id, body.ingredientId));

    // Log the restock
    await db.insert(stockLogs).values({
      outletId,
      ingredientId: body.ingredientId,
      ingredientName: ing.name,
      type: "restock",
      qtyChange: addQty,
      stockBefore,
      stockAfter: newStock,
      note: body.note || `Restock ${addQty} porsi`,
      createdAt: new Date().toISOString(),
    });

    return NextResponse.json({ success: true, stock: newStock });
  } catch (error) {
    console.error("POST restock error:", error);
    return NextResponse.json({ error: "Gagal restock" }, { status: 500 });
  }
}
