import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { ingredients, outlets } from "@/lib/schema";
import { getSession } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const db = getDb();
    const userOutlets = await db.select().from(outlets).where(eq(outlets.userId, session.id)).limit(1);
    if (userOutlets.length === 0) return NextResponse.json([]);

    const items = await db.select().from(ingredients).where(eq(ingredients.outletId, userOutlets[0].id));
    return NextResponse.json(items);
  } catch (error) {
    console.error("GET ingredients error:", error);
    return NextResponse.json({ error: "Gagal mengambil data" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await request.json();
    const db = getDb();
    const userOutlets = await db.select().from(outlets).where(eq(outlets.userId, session.id)).limit(1);
    if (userOutlets.length === 0) return NextResponse.json({ error: "Outlet tidak ditemukan" }, { status: 400 });

    // Auto calculate stock: buyQty / usePerServing = porsi tersedia
    const buyQty = body.buyQty || 0;
    const usePerServing = body.usePerServing || 0;
    const autoStock = (buyQty > 0 && usePerServing > 0) ? Math.floor(buyQty / usePerServing) : 0;

    const [item] = await db.insert(ingredients).values({
      outletId: userOutlets[0].id,
      name: body.name,
      buyPrice: body.buyPrice || 0,
      buyQty: buyQty,
      buyUnit: body.buyUnit || "ml",
      usePerServing: usePerServing,
      stock: autoStock,
      minStock: body.minStock || 0,
      createdAt: new Date().toISOString(),
    }).returning();

    return NextResponse.json(item);
  } catch (error) {
    console.error("POST ingredients error:", error);
    return NextResponse.json({ error: "Gagal menambah bahan" }, { status: 500 });
  }
}
