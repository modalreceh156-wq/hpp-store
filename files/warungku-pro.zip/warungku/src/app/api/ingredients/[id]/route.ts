import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { ingredients } from "@/lib/schema";
import { getSession } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const { id } = await params;
    const body = await request.json();
    const db = getDb();

    // Recalculate stock if buyQty or usePerServing changed
    const buyQty = body.buyQty || 0;
    const usePerServing = body.usePerServing || 0;
    const autoStock = (buyQty > 0 && usePerServing > 0) ? Math.floor(buyQty / usePerServing) : body.stock || 0;

    const [updated] = await db.update(ingredients).set({
      name: body.name,
      buyPrice: body.buyPrice,
      buyQty: buyQty,
      buyUnit: body.buyUnit,
      usePerServing: usePerServing,
      stock: autoStock,
      minStock: body.minStock,
    }).where(eq(ingredients.id, id)).returning();

    return NextResponse.json(updated);
  } catch (error) {
    console.error("PUT ingredients error:", error);
    return NextResponse.json({ error: "Gagal update bahan" }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const { id } = await params;
    const db = getDb();
    await db.delete(ingredients).where(eq(ingredients.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE ingredients error:", error);
    return NextResponse.json({ error: "Gagal hapus bahan" }, { status: 500 });
  }
}
