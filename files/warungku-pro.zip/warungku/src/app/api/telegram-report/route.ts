import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { transactions, outlets, ingredients } from "@/lib/schema";
import { getSession } from "@/lib/auth";
import { eq, gte, and } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const body = await request.json();
    const { chatId, botToken } = body;

    if (!chatId || !botToken) {
      return NextResponse.json({ error: "Chat ID dan Bot Token diperlukan" }, { status: 400 });
    }

    const db = getDb();
    const userOutlets = await db.select().from(outlets).where(eq(outlets.userId, session.id)).limit(1);
    if (userOutlets.length === 0) return NextResponse.json({ error: "Outlet tidak ditemukan" }, { status: 400 });

    const outletId = userOutlets[0].id;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStr = today.toISOString();

    const todayTxns = await db.select().from(transactions)
      .where(and(eq(transactions.outletId, outletId), gte(transactions.createdAt, todayStr)));

    const totalSales = todayTxns.reduce((sum, tx) => sum + tx.totalAmount, 0);
    const totalProfit = todayTxns.reduce((sum, tx) => sum + (tx.totalAmount - tx.totalHpp), 0);
    const txCount = todayTxns.length;

    const allIngredients = await db.select().from(ingredients).where(eq(ingredients.outletId, outletId));
    const lowStock = allIngredients.filter(i => i.minStock > 0 && i.stock <= i.minStock);

    const dateStr = today.toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" });

    let message = `🏪 *Laporan WarungKu*\n📅 ${dateStr}\n\n`;
    message += `💰 Penjualan: Rp ${totalSales.toLocaleString("id-ID")}\n`;
    message += `📈 Profit: Rp ${Math.round(totalProfit).toLocaleString("id-ID")}\n`;
    message += `🧾 Transaksi: ${txCount}\n`;

    if (lowStock.length > 0) {
      message += `\n⚠️ *Stok Menipis:*\n`;
      lowStock.forEach(i => { message += `• ${i.name}: ${i.stock} porsi\n`; });
    }

    message += `\n_Dikirim otomatis oleh WarungKu POS_`;

    const tgRes = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text: message, parse_mode: "Markdown" }),
    });

    if (!tgRes.ok) {
      const err = await tgRes.text();
      return NextResponse.json({ error: `Telegram error: ${err}` }, { status: 500 });
    }

    return NextResponse.json({ success: true, message: "Laporan terkirim ke Telegram!" });
  } catch (error) {
    console.error("POST telegram report error:", error);
    return NextResponse.json({ error: "Gagal mengirim laporan" }, { status: 500 });
  }
}
