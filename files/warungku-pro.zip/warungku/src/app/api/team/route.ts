import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { users, outlets } from "@/lib/schema";
import { getSession, hashPassword } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const db = getDb();
    const userOutlets = await db.select().from(outlets).where(eq(outlets.userId, session.id)).limit(1);
    if (userOutlets.length === 0) return NextResponse.json([]);
    
    // Get all kasir users (non-owner)
    const allUsers = await db.select().from(users);
    const kasir = allUsers.filter(u => u.role === "kasir");
    return NextResponse.json(kasir.map(u => ({ id: u.id, name: u.name, email: u.email, role: u.role })));
  } catch (error) {
    console.error("GET team error:", error);
    return NextResponse.json({ error: "Gagal mengambil data" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const body = await request.json();
    const db = getDb();

    const existing = await db.select().from(users).where(eq(users.email, body.email)).limit(1);
    if (existing.length > 0) return NextResponse.json({ error: "Email sudah terdaftar" }, { status: 400 });

    const passwordHash = await hashPassword(body.password);
    const [kasir] = await db.insert(users).values({
      name: body.name,
      email: body.email,
      passwordHash,
      role: "kasir",
      createdAt: new Date().toISOString(),
    }).returning();

    return NextResponse.json({ id: kasir.id, name: kasir.name, email: kasir.email, role: kasir.role });
  } catch (error) {
    console.error("POST team error:", error);
    return NextResponse.json({ error: "Gagal menambah kasir" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "ID diperlukan" }, { status: 400 });
    const db = getDb();
    await db.delete(users).where(eq(users.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE team error:", error);
    return NextResponse.json({ error: "Gagal hapus kasir" }, { status: 500 });
  }
}
