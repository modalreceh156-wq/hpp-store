import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { users, outlets } from "@/lib/schema";
import { hashPassword, setSession } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const { name, email, password } = await request.json();
    if (!name || !email || !password) {
      return NextResponse.json({ error: "Semua field wajib diisi" }, { status: 400 });
    }
    const db = getDb();
    const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (existing.length > 0) {
      return NextResponse.json({ error: "Email sudah terdaftar" }, { status: 400 });
    }
    const passwordHash = await hashPassword(password);
    const [user] = await db.insert(users).values({ name, email, passwordHash, createdAt: new Date().toISOString() }).returning();
    
    await db.insert(outlets).values({ userId: user.id, name: "Warung Utama", address: "", createdAt: new Date().toISOString() });
    
    await setSession({ id: user.id, email: user.email, name: user.name });
    return NextResponse.json({ success: true, user: { id: user.id, name: user.name, email: user.email } });
  } catch (error) {
    console.error("Register error:", error);
    return NextResponse.json({ error: "Terjadi kesalahan server" }, { status: 500 });
  }
}
