"use client";

import { useEffect, useState } from "react";
import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import { formatCurrency } from "@/lib/utils";
import { Plus, Edit2, Trash2, Search, X, Calculator, Package, RotateCcw, History, AlertTriangle, TrendingUp } from "lucide-react";

interface Ingredient {
  id: string; name: string; buyPrice: number; buyQty: number; buyUnit: string;
  usePerServing: number; stock: number; minStock: number;
}
interface StockLog {
  id: string; ingredientId: string; ingredientName: string; type: string;
  qtyChange: number; stockBefore: number; stockAfter: number; note: string; createdAt: string;
}

const emptyForm = { name: "", buyPrice: 0, buyQty: 0, buyUnit: "ml", usePerServing: 0, minStock: 0 };

export default function BahanPage() {
  const [items, setItems] = useState<Ingredient[]>([]);
  const [logs, setLogs] = useState<StockLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [search, setSearch] = useState("");
  const [showRestock, setShowRestock] = useState<string | null>(null);
  const [restockQty, setRestockQty] = useState(0);
  const [showLogs, setShowLogs] = useState(false);
  const [showLowAlert, setShowLowAlert] = useState(false);

  async function loadData() {
    const [iRes, lRes] = await Promise.all([fetch("/api/ingredients"), fetch("/api/stock-logs")]);
    if (iRes.ok) setItems(await iRes.json());
    if (lRes.ok) setLogs(await lRes.json());
    setLoading(false);
  }

  useEffect(() => {
    loadData();
  }, []);

  // Show low stock alert on mount if any
  useEffect(() => {
    if (items.length > 0) {
      const lowItems = items.filter(i => i.minStock > 0 && i.stock <= i.minStock);
      if (lowItems.length > 0) setShowLowAlert(true);
    }
  }, [items]);

  function calcHpp(buyPrice: number, buyQty: number, usePerServing: number) {
    if (buyQty <= 0 || usePerServing <= 0) return 0;
    return (buyPrice / buyQty) * usePerServing;
  }

  function calcStock(buyQty: number, usePerServing: number) {
    if (buyQty <= 0 || usePerServing <= 0) return 0;
    return Math.floor(buyQty / usePerServing);
  }

  async function handleSave() {
    if (!form.name) return;
    const body = { name: form.name, buyPrice: form.buyPrice, buyQty: form.buyQty, buyUnit: form.buyUnit, usePerServing: form.usePerServing, minStock: form.minStock };
    if (editId) {
      await fetch(`/api/ingredients/${editId}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    } else {
      await fetch("/api/ingredients", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    }
    closeForm();
    loadData();
  }

  async function handleDelete(id: string) {
    if (!confirm("Hapus bahan ini?")) return;
    await fetch(`/api/ingredients/${id}`, { method: "DELETE" });
    loadData();
  }

  function openEdit(item: Ingredient) {
    setEditId(item.id);
    setForm({ name: item.name, buyPrice: item.buyPrice, buyQty: item.buyQty, buyUnit: item.buyUnit, usePerServing: item.usePerServing, minStock: item.minStock });
    setShowForm(true);
  }

  function closeForm() { setShowForm(false); setEditId(null); setForm(emptyForm); }

  async function handleRestock(ingredientId: string) {
    if (restockQty <= 0) return;
    await fetch("/api/restock", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ingredientId, qty: restockQty, note: `Restock ${restockQty} porsi` }),
    });
    setShowRestock(null);
    setRestockQty(0);
    loadData();
  }

  const filtered = items.filter(i => i.name.toLowerCase().includes(search.toLowerCase()));
  const lowStockItems = items.filter(i => i.minStock > 0 && i.stock <= i.minStock);
  const hppPreview = calcHpp(form.buyPrice, form.buyQty, form.usePerServing);
  const stockPreview = calcStock(form.buyQty, form.usePerServing);

  function formatDate(d: string) {
    return new Date(d).toLocaleString("id-ID", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <Header />
      <div className="p-4 space-y-4">
        {/* Low Stock Alert Banner */}
        {lowStockItems.length > 0 && (
          <div className="bg-yellow-50 border border-yellow-300 rounded-xl p-3 flex items-start gap-3">
            <AlertTriangle size={20} className="text-yellow-600 mt-0.5 shrink-0" />
            <div className="flex-1">
              <p className="text-sm font-semibold text-yellow-800">Stok Menipis!</p>
              <div className="mt-1 space-y-0.5">
                {lowStockItems.map(i => (
                  <p key={i.id} className="text-xs text-yellow-700">• {i.name}: <span className="font-bold">{i.stock} porsi</span> (min: {i.minStock})</p>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Search + Add + Log */}
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input type="text" placeholder="Cari bahan..." value={search} onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl text-sm" />
          </div>
          <button onClick={() => setShowLogs(true)} className="bg-gray-100 text-gray-600 px-3 py-3 rounded-xl"><History size={18} /></button>
          <button onClick={() => { closeForm(); setShowForm(true); }} className="bg-emerald-600 text-white px-4 py-3 rounded-xl flex items-center gap-1 font-semibold text-sm"><Plus size={18} /> Tambah</button>
        </div>

        {/* List */}
        {loading ? (
          <div className="text-center py-12"><div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full mx-auto" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-gray-400"><Package size={40} className="mx-auto mb-3 opacity-40" /><p>Belum ada bahan baku</p></div>
        ) : (
          <div className="space-y-2">
            {filtered.map((item) => {
              const hpp = calcHpp(item.buyPrice, item.buyQty, item.usePerServing);
              const isLow = item.minStock > 0 && item.stock <= item.minStock;
              return (
                <div key={item.id} className={`bg-white rounded-xl p-4 shadow-sm border ${isLow ? 'border-yellow-300 bg-yellow-50' : 'border-gray-100'}`}>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{item.name}</h3>
                      <p className="text-xs text-gray-500 mt-0.5">{formatCurrency(item.buyPrice)} / {item.buyQty} {item.buyUnit} • pakai {item.usePerServing} {item.buyUnit}/porsi</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-lg font-bold ${isLow ? 'text-yellow-600' : 'text-emerald-600'}`}>{item.stock}</p>
                      <p className="text-xs text-gray-400">porsi</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-50">
                    <div className="flex items-center gap-1">
                      <Calculator size={14} className="text-emerald-500" />
                      <span className="text-sm font-medium text-emerald-600">HPP: {formatCurrency(Math.round(hpp))}/porsi</span>
                    </div>
                    <div className="flex gap-1">
                      <button onClick={() => { setShowRestock(item.id); setRestockQty(0); }} className="text-xs text-emerald-600 bg-emerald-50 px-2.5 py-1.5 rounded-lg font-medium flex items-center gap-1">
                        <RotateCcw size={12} /> Restock
                      </button>
                      <button onClick={() => openEdit(item)} className="text-xs text-blue-600 bg-blue-50 px-2 py-1.5 rounded-lg"><Edit2 size={12} /></button>
                      <button onClick={() => handleDelete(item.id)} className="text-xs text-red-500 bg-red-50 px-2 py-1.5 rounded-lg"><Trash2 size={12} /></button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Restock Modal */}
      {showRestock && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">📦 Restock</h2>
              <button onClick={() => setShowRestock(null)} className="p-1"><X size={20} /></button>
            </div>
            <p className="text-sm text-gray-500">Tambah stok: <span className="font-semibold">{items.find(i => i.id === showRestock)?.name}</span></p>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Jumlah Porsi Ditambah</label>
              <input type="number" value={restockQty || ""} onChange={(e) => setRestockQty(Number(e.target.value))}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-xl font-bold text-center focus:border-emerald-500 outline-none" placeholder="0" />
            </div>
            {restockQty > 0 && (
              <div className="bg-emerald-50 rounded-xl p-3 text-center">
                <p className="text-sm text-emerald-700">Stok sekarang: <span className="font-bold">{items.find(i => i.id === showRestock)?.stock}</span> → <span className="font-bold">{(items.find(i => i.id === showRestock)?.stock || 0) + restockQty}</span> porsi</p>
              </div>
            )}
            <button onClick={() => handleRestock(showRestock)} disabled={restockQty <= 0}
              className="w-full bg-emerald-600 text-white py-3 rounded-xl font-semibold hover:bg-emerald-700 disabled:opacity-40">
              Restock Sekarang
            </button>
          </div>
        </div>
      )}

      {/* Stock Log Modal */}
      {showLogs && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-end sm:items-center justify-center">
          <div className="bg-white rounded-t-2xl sm:rounded-2xl w-full max-w-md max-h-[80vh] flex flex-col">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between">
              <h2 className="text-lg font-semibold">📋 Riwayat Stok</h2>
              <button onClick={() => setShowLogs(false)} className="p-1"><X size={20} /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {logs.length === 0 ? (
                <p className="text-center text-gray-400 py-8">Belum ada riwayat</p>
              ) : logs.map((log) => (
                <div key={log.id} className="bg-gray-50 rounded-xl p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        log.type === "restock" ? "bg-emerald-100 text-emerald-700" :
                        log.type === "sale" ? "bg-red-100 text-red-700" :
                        "bg-gray-100 text-gray-700"
                      }`}>
                        {log.type === "restock" ? "📦 Restock" : log.type === "sale" ? "🛒 Jual" : log.type}
                      </span>
                      <span className="font-medium text-sm">{log.ingredientName}</span>
                    </div>
                    <span className="text-xs text-gray-400">{formatDate(log.createdAt)}</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    {log.stockBefore} → <span className={log.type === "restock" ? "text-emerald-600 font-medium" : "text-red-600 font-medium"}>{log.stockAfter}</span>
                    {log.type === "restock" && <span className="text-emerald-600"> (+{log.qtyChange})</span>}
                    {log.type === "sale" && <span className="text-red-600"> (-{Math.abs(log.qtyChange)})</span>}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-end sm:items-center justify-center">
          <div className="bg-white rounded-t-2xl sm:rounded-2xl w-full max-w-md p-6 space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">{editId ? "Edit Bahan" : "Tambah Bahan"}</h2>
              <button onClick={closeForm} className="p-1"><X size={20} /></button>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">① Nama Bahan</label>
              <input type="text" value={form.name} onChange={(e) => setForm({...form, name: e.target.value})}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm" placeholder="Kopi, Gula, Susu" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">② Harga & Isi Kemasan</label>
              <div className="grid grid-cols-2 gap-3">
                <div><span className="text-xs text-gray-400">Harga beli (Rp)</span>
                  <input type="number" value={form.buyPrice || ""} onChange={(e) => setForm({...form, buyPrice: Number(e.target.value)})}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm mt-1" placeholder="53000" /></div>
                <div><span className="text-xs text-gray-400">Isi kemasan</span>
                  <input type="number" value={form.buyQty || ""} onChange={(e) => setForm({...form, buyQty: Number(e.target.value)})}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm mt-1" placeholder="500" /></div>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">③ Satuan</label>
              <div className="flex gap-2 flex-wrap">
                {["ml", "gram", "liter", "kg", "pcs", "butir", "lembar", "batang"].map((u) => (
                  <button key={u} type="button" onClick={() => setForm({...form, buyUnit: u})}
                    className={`px-3 py-2 rounded-lg text-sm font-medium ${form.buyUnit === u ? "bg-emerald-600 text-white" : "bg-gray-100 text-gray-600"}`}>{u}</button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">④ Pakai Per Porsi</label>
              <div className="flex items-center gap-2">
                <input type="number" value={form.usePerServing || ""} onChange={(e) => setForm({...form, usePerServing: Number(e.target.value)})}
                  className="flex-1 px-4 py-3 border border-gray-200 rounded-xl text-sm" placeholder="30" />
                <span className="text-sm text-gray-500 font-medium">{form.buyUnit}</span>
              </div>
            </div>
            {form.buyPrice > 0 && form.buyQty > 0 && form.usePerServing > 0 && (
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">HPP per porsi</span>
                  <span className="text-lg font-bold text-emerald-600">{formatCurrency(Math.round(hppPreview))}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Stok (porsi tersedia)</span>
                  <span className="text-lg font-bold text-emerald-600">{stockPreview} porsi</span>
                </div>
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">⚠️ Alert Stok Minimum</label>
              <input type="number" value={form.minStock || ""} onChange={(e) => setForm({...form, minStock: Number(e.target.value)})}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm" placeholder="5 (alert kalau sisa 5 porsi)" />
            </div>
            <button onClick={handleSave} className="w-full bg-emerald-600 text-white py-3.5 rounded-xl font-semibold hover:bg-emerald-700">
              {editId ? "Simpan Perubahan" : "Tambah Bahan"}
            </button>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
